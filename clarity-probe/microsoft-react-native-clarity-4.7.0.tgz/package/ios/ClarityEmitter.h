#import <React/RCTEventEmitter.h>


@interface ClarityEmitter : RCTEventEmitter <RCTBridgeModule>

@end
