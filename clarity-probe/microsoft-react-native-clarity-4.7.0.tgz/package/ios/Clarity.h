#import <React/RCTBridgeModule.h>

@interface Clarity : NSObject <RCTBridgeModule>

@end
